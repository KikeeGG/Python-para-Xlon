from funciones_all import *
#PROGRAMA Y EJECUCIÓN MAS VARIABLES
articulos = []
usuarios = []
ventas = []
carrito_actual = []
usuario_activo = None

menu_principal(articulos, usuarios, ventas, carrito_actual, usuario_activo)
